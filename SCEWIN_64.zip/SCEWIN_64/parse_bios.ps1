$inputFile = "BIOSSettings2.txt"
$outputFile = "BIOSSettings.txt"

$content = Get-Content $inputFile -Encoding ASCII

$header = @()
$body = @()
$inHeader = $true

# Séparer l'en-tête
foreach ($line in $content) {
    if ($inHeader) {
        $header += $line
        if ($line -match "^HIIcrc32=") {
            $inHeader = $false
        }
    } else {
        $body += $line
    }
}

$output = @()
$output += $header
$output += ""

$currentBlock = @()
$currentParam = ""
$insideBlock = $false

foreach ($line in $body) {
    if ($line -match "^Setup Question\s*=\s*(.+)$") {
        # Sauvegarder le bloc précédent si valide
        if ($currentBlock.Count -gt 0) {
            $modifiedBlock = @()
            foreach ($bLine in $currentBlock) {
                $lineTrim = $bLine.TrimStart()
                # Supprimer les astérisques existants
                if ($lineTrim.StartsWith("*[")) {
                    $bLine = "         " + $lineTrim.Substring(1)
                }
                # Ajouter * avant [00]Disable ou [00]Disabled
                if ($bLine.Trim() -match "^\[\d{2}\](Disable|Disabled)\b" -and -not $bLine.Trim().StartsWith("*")) {
                    $bLine = $bLine -replace "^\s*(\[\d{2}\](Disable|Disabled))", '         *$1'
                }
                $modifiedBlock += $bLine
            }
            $output += $modifiedBlock
            $output += ""
        }
        $currentBlock = @($line)
        $currentParam = $matches[1].Trim()
        $insideBlock = $true
    }
    elseif ($insideBlock) {
        if ($line -match "^\s*$") {
            # Sauvegarder le dernier bloc si valide
            $modifiedBlock = @()
            foreach ($bLine in $currentBlock) {
                $lineTrim = $bLine.TrimStart()
                # Supprimer les astérisques existants
                if ($lineTrim.StartsWith("*[")) {
                    $bLine = "         " + $lineTrim.Substring(1)
                }
                # Ajouter * avant [00]Disable ou [00]Disabled
                if ($bLine.Trim() -match "^\[\d{2}\](Disable|Disabled)\b" -and -not $bLine.Trim().StartsWith("*")) {
                    $bLine = $bLine -replace "^\s*(\[\d{2}\](Disable|Disabled))", '         *$1'
                }
                $modifiedBlock += $bLine
            }
            $output += $modifiedBlock
            $output += ""
            $currentBlock = @()
            $currentParam = ""
            $insideBlock = $false
        } else {
            $currentBlock += $line
        }
    }
}

# Dernier bloc à traiter
if ($currentBlock.Count -gt 0) {
    $modifiedBlock = @()
    foreach ($bLine in $currentBlock) {
        $lineTrim = $bLine.TrimStart()
        # Supprimer les astérisques existants
        if ($lineTrim.StartsWith("*[")) {
            $bLine = "         " + $lineTrim.Substring(1)
        }
        # Ajouter * avant [00]Disable ou [00]Disabled
        if ($bLine.Trim() -match "^\[\d{2}\](Disable|Disabled)\b" -and -not $bLine.Trim().StartsWith("*")) {
            $bLine = $bLine -replace "^\s*(\[\d{2}\](Disable|Disabled))", '         *$1'
        }
        $modifiedBlock += $bLine
    }
    $output += $modifiedBlock
    $output += ""
}

# Écrire le fichier final
Set-Content -Path $outputFile -Value $output -Encoding ASCII
